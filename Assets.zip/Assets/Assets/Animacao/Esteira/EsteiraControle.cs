using UnityEngine;

/// <summary>
/// Controla o funcionamento da esteira.
/// Responsável por animar o movimento da textura através de um parâmetro do shader.
/// </summary>
public class EsteiraControle : MonoBehaviour
{
    [Header("Referência do Material")]
    [SerializeField] private Material materialEsteira; 
    // Material que contém o Shader Graph da esteira

    [Header("Configuração de Movimento")]
    [SerializeField] private float velocidade = 1f; 
    // Velocidade de deslocamento da textura

    // Estado atual da esteira
    private bool estaLigada = false;

    /// <summary>
    /// Atualização executada a cada frame.
    /// Se a esteira estiver ligada, atualiza o valor do shader para gerar movimento.
    /// </summary>
    private void Update()
    {
        // Se a esteira não estiver ligada, não executa o movimento
        if (!estaLigada)
            return;

        // Verifica se o material foi atribuído no Inspector
        if (materialEsteira == null)
        {
            Debug.LogWarning("EsteiraControle: material da esteira não foi atribuído.");
            return;
        }

        // Calcula o deslocamento da textura ao longo do tempo
        float deslocamento = Time.time * velocidade;

        // Atualiza o parâmetro do shader responsável pela animação
        materialEsteira.SetFloat("_Velocidade", deslocamento);
    }

    /// <summary>
    /// Liga a esteira e inicia o movimento da textura.
    /// </summary>
    public void LigarEsteira()
    {
        estaLigada = true;
        Debug.Log("Esteira ligada.");
    }

    /// <summary>
    /// Desliga a esteira, interrompendo o movimento.
    /// </summary>
    public void DesligarEsteira()
    {
        estaLigada = false;
        Debug.Log("Esteira desligada.");
    }
}