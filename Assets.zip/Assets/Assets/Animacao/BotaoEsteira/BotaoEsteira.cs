using UnityEngine;
using System.Collections;

/// <summary>
/// Controla o comportamento do botão físico da esteira.
/// Quando clicado, o botão afunda visualmente e aciona a esteira.
/// </summary>
public class BotaoEsteira : MonoBehaviour
{
    [Header("Referências")]
    [SerializeField] private EsteiraControle esteira; // Referência ao script que controla a esteira

    [Header("Configurações do Botão")]
    [SerializeField] private float distanciaAfundar = 0.02f; // Distância que o botão irá afundar
    [SerializeField] private float velocidadeAnimacao = 6f;  // Velocidade da animação de pressionamento
    [SerializeField] private float tempoPressionado = 0.1f;  // Tempo que o botão permanece pressionado

    // Guarda a posição inicial do botão
    private Vector3 posicaoInicial;

    /// <summary>
    /// Executado quando o objeto é inicializado.
    /// Armazena a posição original do botão.
    /// </summary>
    private void Start()
    {
        posicaoInicial = transform.position;
    }

    public void Interagir()
{
    // Verifica se a referência da esteira foi atribuída
    if (esteira == null)
    {
        Debug.LogWarning("BotaoEsteira: referência da esteira não definida no Inspector.");
        return;
    }

    // Inicia a animação do botão
    StartCoroutine(AnimarPressionamento());

    // Liga a esteira
    esteira.LigarEsteira();
}
    /// <summary>
    /// Evento chamado automaticamente pelo Unity
    /// quando o jogador clica no objeto que possui um Collider.
    /// </summary>
    private void OnMouseDown()
    {
        // Verifica se a referência da esteira foi atribuída
        if (esteira == null)
        {
            Debug.LogWarning("BotaoEsteira: referência da esteira não definida no Inspector.");
            return;
        }

        // Inicia a animação de pressionamento do botão
        StartCoroutine(AnimarPressionamento());

        // Aciona a esteira
        esteira.LigarEsteira();
    }

    /// <summary>
    /// Coroutine responsável por animar o botão afundando e retornando à posição original.
    /// </summary>
    private IEnumerator AnimarPressionamento()
    {
        // Direção para dentro do botão (baseado na orientação local do objeto)
        Vector3 direcaoPressionamento = transform.forward;

        // Calcula a posição pressionada
        Vector3 posicaoPressionada = posicaoInicial - direcaoPressionamento * distanciaAfundar;

        float progresso = 0f;

        // Animação de descida do botão
        while (progresso < 1f)
        {
            progresso += Time.deltaTime * velocidadeAnimacao;
            transform.position = Vector3.Lerp(posicaoInicial, posicaoPressionada, progresso);
            yield return null;
        }

        // Pequena pausa enquanto o botão está pressionado
        yield return new WaitForSeconds(tempoPressionado);

        progresso = 0f;

        // Animação de retorno do botão
        while (progresso < 1f)
        {
            progresso += Time.deltaTime * velocidadeAnimacao;
            transform.position = Vector3.Lerp(posicaoPressionada, posicaoInicial, progresso);
            yield return null;
        }
    }
}